﻿namespace WebApiTemplate.Api.Infrastructure.Mapping
{
    public interface IMapFrom<TModel>
    {
    }
}